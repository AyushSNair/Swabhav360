import admin from './firebaseAdmin.js';

const db = admin.firestore();

export default db;
